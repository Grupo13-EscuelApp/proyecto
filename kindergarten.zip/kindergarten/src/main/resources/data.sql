INSERT INTO parent (id, first_name, last_name, email) VALUES
  ('1', 'Natalia', 'Moreno', 'hacktalia@hacker.com'),
  ('2', 'Manuel', 'Fernandez', 'manuel.fernandez@gmail.com');