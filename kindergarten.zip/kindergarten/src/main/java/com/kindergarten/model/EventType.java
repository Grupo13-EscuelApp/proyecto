package com.kindergarten.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import java.util.List;

@Entity
@Table(name = "event_type")
public class EventType {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    private String name;

    @OneToMany(mappedBy = "eventType")
    private List<Event> events;

    // getters y setters

    public EventType() {
    }   

    public Integer getId() {
        return id;
    }  

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }   

    public void setName(String name) {
        this.name = name;
    }   

    public List<Event> getEvents() {
        return events;
    }   

    public void setEvents(List<Event> events) {
        this.events = events;
    } 

    @Override
    public String toString() {
        return "TypeEvent{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}
