package com.kindergarten.model;


import java.sql.Timestamp;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Event {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

    private Timestamp date;

    @ManyToOne
    @JoinColumn(name = "child_id")
    private Child child;

    @ManyToOne
    @JoinColumn(name = "event_type_id")
    private EventType eventType;

    
    public Event() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }   

    public Timestamp getDate() {
        return date;
    }   

    public void setDate(Timestamp date) {
        this.date = date;
    }      

    @Override
    public String toString() {
        return "Event{" +
                "id='" + id + '\'' +
                ", date='" + date + '\'' +
                '}';
    }
}
