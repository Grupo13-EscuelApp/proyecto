package com.kindergarten.service;

import com.kindergarten.model.EventType;
import com.kindergarten.repository.EventTypeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.kindergarten.exception.ResourceNotFoundException;

import java.util.List;

@Service
public class EventTypeService {

    @Autowired
    private EventTypeRepository eventTypeRepository;

    public List<EventType> getAllEventTypes() {
        return eventTypeRepository.findAll();
    }

    public EventType getEventTypeById(Integer id) {
        return eventTypeRepository.findById(id).orElse(null);
    }

    public EventType addEventType(EventType eventType) {
        return eventTypeRepository.save(eventType);
    }

    public EventType updateEventType(Integer id, EventType eventTypeDetails) {
        EventType eventType = eventTypeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("EventType", "id", id));

        eventType.setName(eventTypeDetails.getName());
        
        EventType updatedEventType = eventTypeRepository.save(eventType);
        return updatedEventType;
    }

    public ResponseEntity<?> deleteEventType(Integer id) {
        EventType eventType = eventTypeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("EventType", "id", id));

        eventTypeRepository.delete(eventType);

        return ResponseEntity.ok().build();
    }
}