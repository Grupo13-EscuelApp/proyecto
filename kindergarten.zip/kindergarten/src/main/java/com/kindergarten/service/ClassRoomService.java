package com.kindergarten.service;

import com.kindergarten.model.Classroom;
import com.kindergarten.repository.ClassRoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.kindergarten.exception.ResourceNotFoundException;

import java.util.List;

@Service
public class ClassRoomService {

    @Autowired
    private ClassRoomRepository classRoomRepository;

    public List<Classroom> getAllClassrooms() {
        return classRoomRepository.findAll();
    }

    public Classroom getClassroomById(Integer id) {
        return classRoomRepository.findById(id).orElse(null);
    }

    public Classroom addClassroom(Classroom classroom) {
        return classRoomRepository.save(classroom);
    }

    public Classroom updateClassroom(Integer id, Classroom classroomDetails) {
        Classroom classroom = classRoomRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Classroom", "id", id));

        classroom.setName(classroomDetails.getName());
        

        Classroom updatedClassroom = classRoomRepository.save(classroom);
        return updatedClassroom;
    }

    public ResponseEntity<?> deleteClassroom(Integer id) {
        Classroom classroom = classRoomRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Classroom", "id", id));

        classRoomRepository.delete(classroom);

        return ResponseEntity.ok().build();
    }
}