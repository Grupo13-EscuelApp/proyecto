package com.kindergarten.service;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import com.kindergarten.exception.ResourceNotFoundException;
import com.kindergarten.model.Child;

import com.kindergarten.repository.ChildRepository; 

@Service
public class ChildService {

    private final ChildRepository childRepository;

    @Autowired
    public ChildService(ChildRepository childRepository) {
        this.childRepository = childRepository;
    }

    public List<Child> getAllChildren() {
        return childRepository.findAll();
    }

    public Child getChildById(Integer id) {
        return childRepository.findById(id).orElse(null);
    }

    public Child saveChild(Child child) {
        return childRepository.save(child);
    }

    public void deleteChild(Integer id) {
        childRepository.deleteById(id);
    }

    public Child updateChild(Integer id, Child childDetails) {
        Child child = childRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Child", "id", id));

        child.setFirstName(childDetails.getFirstName());
        child.setLastName(childDetails.getLastName());
        child.setAge(childDetails.getAge());
        child.setEvent(childDetails.getEvent());
        child.setClassroom(childDetails.getClassroom());
        
       
        Child updatedChild = childRepository.save(child);
        return updatedChild;
    }
}