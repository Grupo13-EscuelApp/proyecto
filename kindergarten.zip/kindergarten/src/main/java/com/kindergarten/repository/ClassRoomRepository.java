package com.kindergarten.repository;

import com.kindergarten.model.Classroom;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClassRoomRepository extends JpaRepository<Classroom, Integer> {
}