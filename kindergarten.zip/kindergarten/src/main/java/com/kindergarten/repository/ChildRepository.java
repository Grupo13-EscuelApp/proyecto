package com.kindergarten.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.kindergarten.model.Child;

public interface ChildRepository extends JpaRepository<Child, Integer> {
}
