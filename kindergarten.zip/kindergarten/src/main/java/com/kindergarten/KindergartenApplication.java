package com.kindergarten;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication(scanBasePackages = {"com.kindergarten", "com.kindergarten.controller", "com.kindergarten.service", "com.kindergarten.repository", "com.kindergarten.model"})
@Configuration
@EnableTransactionManagement
@EnableAutoConfiguration
@EnableJpaRepositories(basePackages = {"com.kindergarten.repository"})
@ComponentScan({"com.kindergarten.config","com.kindergarten.controller","com.kindergarten.service","com.kindergarten.repository","com.kindergarten.model"})
public class KindergartenApplication {

	public static void main(String[] args) {
		SpringApplication.run(KindergartenApplication.class, args);
	}

}
