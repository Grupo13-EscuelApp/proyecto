package com.kindergarten.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import com.kindergarten.model.Child;
import com.kindergarten.service.ChildService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@Tag(name = "Children", description = "Gestión de alumnos de la guardería")
@RestController
@RequestMapping("/kindergarten/api/v1/children")
public class ChildController {

    private final ChildService childService;

    @Autowired
    public ChildController(ChildService childService) {
        this.childService = childService;
    }

    @Operation(summary = "Obtener todos los niños de la guarderia", description = "Obtiene una lista con todos los niños de la guardería")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Lista de alumnos obtenida con éxito")
    })
    @GetMapping("/")
    public List<Child> getAllChildren() {
        return childService.getAllChildren();
    }

    @GetMapping("/{id}")
    public Child getChildById(@PathVariable Integer id) {
        return childService.getChildById(id);
    }

    @Operation(summary = "Crear un alumno de la guardería", description = "Crea un alumno de la guardería")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Alumno creado con éxito")
    })
    @PostMapping("/")
    public Child createChild(@RequestBody Child child) {
        return childService.saveChild(child);
    }

    @DeleteMapping("/{id}")
    public void deleteChild(@PathVariable Integer id) {
        childService.deleteChild(id);
    }

    @Operation(summary = "Actualizar un alumno de la guardería", description = "Actualiza un alumno de la guardería por su id")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Alumno actualizado con éxito"),
            @ApiResponse(responseCode = "404", description = "Alumno no encontrado")
    })
    @PutMapping("/{id}")
    public Child updateChild(@PathVariable Integer id, @RequestBody Child childDetails) {
        return childService.updateChild(id, childDetails);
    }
}
