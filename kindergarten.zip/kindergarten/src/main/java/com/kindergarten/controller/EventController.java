package com.kindergarten.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.kindergarten.service.EventService;
import com.kindergarten.model.Event;

import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

//swagger
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.*;


@Tag(name = "Event", description = "Gestión de eventos de los niños")
@RestController
@RequestMapping("/kindergarten/api/v1/event")
public class EventController {

    @Autowired
    private EventService eventService;


    @Operation(
        summary = "Obtener todos los eventos de los niños",
        description = "Obtiene una lista con todos los eventos de los niños"
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Lista de eventos obtenida con éxito")
    })
    @GetMapping("/")
    public List<Event> getAllEvents() {
        return eventService.getAllEvents();
    }

    @Operation(
        summary = "Crear un evento de un alumno",
        description = "Crea un evento de la guardería"
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Evento creado con éxito")
    })  
    @PostMapping("/")
    public Event createEvent(@RequestBody Event event) {
        return eventService.addEvent(event);
    }


    @Operation(
        summary = "Obtener un evento de un alumno",
        description = "Obtiene un evento de un alumno por su id"
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Evento obtenido con éxito"),
        @ApiResponse(responseCode = "404", description = "Evento no encontrado")
    })
    @GetMapping("/{id}")
    public Event getEvent(@PathVariable Integer id) {
        return eventService.getEventById(id);
    }


    @Operation(
        summary = "Actualizar un evento de la guardería",
        description = "Actualiza un evento de la guardería por su id"
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Evento actualizado con éxito"),
        @ApiResponse(responseCode = "404", description = "Evento no encontrado")
    })
    @PutMapping("/{id}")
    public Event updateEvent(@PathVariable Integer id, @RequestBody Event eventDetails) {
        return eventService.updateEvent(id, eventDetails);
    }


    @Operation(
        summary = "Eliminar un evento de un alumno",
        description = "Elimina un evento de un alumno por su id"
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Evento eliminado con éxito"),
        @ApiResponse(responseCode = "404", description = "Evento no encontrado")
    })  
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteEvent(@PathVariable Integer id) {
        eventService.deleteEvent(id);
        return ResponseEntity.ok().build();
    }

}