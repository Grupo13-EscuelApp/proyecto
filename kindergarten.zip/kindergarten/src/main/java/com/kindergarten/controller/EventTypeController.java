package com.kindergarten.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.kindergarten.service.EventTypeService;
import com.kindergarten.model.EventType;

import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

//swagger
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.*;


@Tag(name = "EventType", description = "Gestión de tipos de eventos de alumnos de la guardería")
@RestController
@RequestMapping("/kindergarten/api/v1/eventType")
public class EventTypeController {

    @Autowired
    private EventTypeService eventTypeService;


    @Operation(
        summary = "Obtener todos los tipos de eventos de alumnos de la guardería",
        description = "Obtiene una lista con todos los tipos de eventos de alumnos de la guardería"
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Lista de tipos de eventos obtenida con éxito")
    })
    @GetMapping("/")
    public List<EventType> getAllEventTypes() {
        return eventTypeService.getAllEventTypes();
    }

    @Operation(
        summary = "Crear un tipo de evento de un alumno de la guardería",
        description = "Crea un tipo de evento de un alumno de la guardería"
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Tipo de evento creado con éxito")
    })  
    @PostMapping("/")
    public EventType createEventType(@RequestBody EventType eventType) {
        return eventTypeService.addEventType(eventType);
    }


    @Operation(
        summary = "Obtener tipos de eventos de alumno de la guardería",
        description = "Obtiene tipos de ventos de alumno de la guardería por su id"
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Tipo de evento obtenido con éxito"),
        @ApiResponse(responseCode = "404", description = "Tipo de evento no encontrado")
    })
    @GetMapping("/{id}")
    public EventType getEventType(@PathVariable Integer id) {
        return eventTypeService.getEventTypeById(id);
    }


    @Operation(
        summary = "Actualizar un tipo de evento de alumno de la guardería",
        description = "Actualiza un tipo de evento de alumno de la guardería por su id"
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Tipo de evento actualizado con éxito"),
        @ApiResponse(responseCode = "404", description = "Tipo de evento no encontrado")
    })
    @PutMapping("/{id}")
    public EventType updateEventType(@PathVariable Integer id, @RequestBody EventType eventTypeDetails) {
        return eventTypeService.updateEventType(id, eventTypeDetails);
    }


    @Operation(
        summary = "Eliminar un tipo de evento de alumno de la guardería",
        description = "Elimina un tipo de evento de alumno de la guardería por su id"
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Tipo de evento eliminado con éxito"),
        @ApiResponse(responseCode = "404", description = "Tipo de evento no encontrado")
    })  
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteEventType(@PathVariable Integer id) {
        eventTypeService.deleteEventType(id);
        return ResponseEntity.ok().build();
    }

}