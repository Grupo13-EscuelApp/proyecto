package com.kindergarten.kindergarten;

import com.kindergarten.controller.ParentController;
import com.kindergarten.controller.ClassRoomController;
import com.kindergarten.controller.EventController;
import com.kindergarten.controller.ChildController;
import com.kindergarten.controller.EventTypeController;
import com.kindergarten.controller.TeacherController;



import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.bind.annotation.PathVariable;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class KindergartenApplicationTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void getAllParentsTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/parent"))
                .andExpect(status().isNotFound());
               
    }


    @Test
    public void createParentTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/parent"))
                .andExpect(status().isNotFound());
               
    }

    @Test
    public void updateParentTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/parent"))
                .andExpect(status().isNotFound());
               
    }

    @Test
    public void getParentTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/parent"))
                .andExpect(status().isNotFound());
               
    }


    @Test
    public void deleteParentTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/parent"))
                .andExpect(status().isNotFound());
               
    }

    @Test
    public void getAllClassroomsTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/classroom"))
                .andExpect(status().isNotFound());
               
    }

    @Test
    public void createClassroomTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/classroom"))
                .andExpect(status().isNotFound());
               
    }

    @Test
    public void updateClassroomTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/classroom"))
                .andExpect(status().isNotFound());
               
    }


    @Test
    public void getClassroomTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/classroom"))
                .andExpect(status().isNotFound());
               
    }
    


    @Test
    public void deleteClassroomTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/classroom"))
                .andExpect(status().isNotFound());
               
    }


    @Test
    public void getAllEventsTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/event"))
                .andExpect(status().isNotFound());
               
    }

    @Test
    public void createEventTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/event"))
                .andExpect(status().isNotFound());
               
    }

    @Test
    public void updateEventTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/event"))
                .andExpect(status().isNotFound());
               
    }

    @Test
    public void getEventByIdTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/event"))
                .andExpect(status().isNotFound());
               
    }


    @Test
    public void deleteEventTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/event"))
                .andExpect(status().isNotFound());
               
    }

    @Test
    public void getAllChildrenTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/children"))
                .andExpect(status().isNotFound());
               
    }

    @Test
    public void createChildTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/children"))
                .andExpect(status().isNotFound());
               
    }

    @Test
    public void updateChildTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/children"))
                .andExpect(status().isNotFound());
               
    }

    @Test
    public void getChildByIdTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/children"))
                .andExpect(status().isNotFound());
               
    }


    @Test
    public void deleteChildTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/children"))
                .andExpect(status().isNotFound());
               
    }

    @Test
    public void etAllEventTypesTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/eventType"))
                .andExpect(status().isNotFound());
               
    }


    @Test
    public void createEventTypeTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/eventType"))
                .andExpect(status().isNotFound());
               
    }

    @Test
    public void updateEventTypeTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/eventType"))
                .andExpect(status().isNotFound());
               
    }

    @Test
    public void getEventTypeTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/eventType"))
                .andExpect(status().isNotFound());
               
    }


    @Test
    public void deleteEventTypeTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/eventType"))
                .andExpect(status().isNotFound());
    }
    @Test
    public void getAllTeachersTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/teacher"))
                .andExpect(status().isNotFound());
               
    }


    @Test
    public void createTeacherTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/teacher"))
                .andExpect(status().isNotFound());
               
    }

    @Test
    public void updateTeacherTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/teacher"))
                .andExpect(status().isNotFound());
               
    }

    @Test
    public void getTeacherTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/teacher"))
                .andExpect(status().isNotFound());
               
    }


    @Test
    public void deleteTeacherTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/teacher"))
                .andExpect(status().isNotFound());
               
    }

}
