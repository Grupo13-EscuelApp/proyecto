package com.kindergarten.kindergarten;

import com.kindergarten.controller.ParentController;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class KindergartenApplicationTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void getAllParentsTest() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/kindergarten/api/v1/parent"))
                .andExpect(status().isNotFound());
               
    }
}
