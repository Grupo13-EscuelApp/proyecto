package com.kindergarten.service;

import com.kindergarten.model.Parent;
import com.kindergarten.repository.ParentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.kindergarten.exception.ResourceNotFoundException;

import java.util.List;

@Service
public class ParentService {

    @Autowired
    private ParentRepository parentRepository;

    public List<Parent> getAllParents() {
        return parentRepository.findAll();
    }

    public Parent getParentById(Integer id) {
        return parentRepository.findById(id).orElse(null);
    }

    public Parent addParent(Parent parent) {
        return parentRepository.save(parent);
    }

    public Parent updateParent(Integer id, Parent parentDetails) {
        Parent parent = parentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Parent", "id", id));

        parent.setFirstName(parentDetails.getFirstName());
        parent.setLastName(parentDetails.getLastName());
        parent.setEmail(parentDetails.getEmail());

        Parent updatedParent = parentRepository.save(parent);
        return updatedParent;
    }

    public ResponseEntity<?> deleteParent(Integer id) {
        Parent parent = parentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Parent", "id", id));

        parentRepository.delete(parent);

        return ResponseEntity.ok().build();
    }
}