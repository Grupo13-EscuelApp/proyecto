package com.kindergarten.service;

import com.kindergarten.model.Child;
import com.kindergarten.repository.ChildRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.kindergarten.exception.ResourceNotFoundException;

import java.util.List;

@Service
public class ChildService {

    @Autowired
    private ChildRepository childRepository;

    public List<Child> getAllChild() {
        return childRepository.findAll();
    }

    public Child getChildById(Integer id) {
        return childRepository.findById(id).orElse(null);
    }

    public Child addChild(Child child) {
        return childRepository.save(child);
    }

    public Child updateChild(Integer id, Child childDetails) {
        Child child = childRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Child", "id", id));

        child.setFirstName(childDetails.getFirstName());
        child.setLastName(childDetails.getLastName());
        child.setEmail(childDetails.getEmail());

        Child updatedChild = childRepository.save(child);
        return updatedChild;
    }

    public ResponseEntity<?> deleteChild(Integer id) {
        Child child = childRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Child", "id", id));

        childRepository.delete(child);

        return ResponseEntity.ok().build();
    }
}