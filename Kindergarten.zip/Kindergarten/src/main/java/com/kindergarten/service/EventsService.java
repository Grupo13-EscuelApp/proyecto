package com.kindergarten.service;

import com.kindergarten.model.Events;
import com.kindergarten.repository.EventsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.kindergarten.exception.ResourceNotFoundException;

import java.util.List;

@Service
public class EventsService {

    @Autowired
    private EventsRepository eventsRepository;

    public List<Events> getAllEvents() {
        return eventsRepository.findAll();
    }

    public Events getEventsById(Integer id) {
        return eventsRepository.findById(id).orElse(null);
    }

    public Events addEvents(Events events) {
        return eventsRepository.save(events);
    }

    public Events updateEvents(Integer id, Events eventsDetails) {
        Events events = eventsRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Events", "id", id));

        events.setFirstName(eventsDetails.getFirstName());
        events.setLastName(eventsDetails.getLastName());
        events.setCircunstancias(eventsDetails.getCircunstancias());
        events.setEmail(eventsDetails.getEmail());

        Events updatedEvents = eventsRepository.save(events);
        return updatedEvents;
    }

    public ResponseEntity<?> deleteEvents(Integer id) {
        Events events = eventsRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Events", "id", id));

        eventsRepository.delete(events);

        return ResponseEntity.ok().build();
    }
}