package com.kindergarten.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.kindergarten.service.ChildService;
import com.kindergarten.model.Child;

import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

//swagger
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.*;


@Tag(name = "Child", description = "Gestión de alumnos de la guardería")
@RestController
@RequestMapping("/kindergarten/api/v1/child")
public class ChildController {

    @Autowired
    private ChildService childService;


    @Operation(
        summary = "Obtener todos los alumnos de la guardería",
        description = "Obtiene una lista con todos los alumnos de la guardería"
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Lista de alumnos obtenida con éxito")
    })
    @GetMapping("/")
    public List<Child> getAllChilds() {
        return childService.getAllChild();
    }

    @Operation(
        summary = "Crear un  alumno de la guardería",
        description = "Crea un alumno de la guardería"
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Alumno creado con éxito")
    })  
    @PostMapping("/")
    public Child createChild(@RequestBody Child child) {
        return childService.addChild(child);
    }


    @Operation(
        summary = "Obtener un alumno de la guardería",
        description = "Obtiene un alumno de la guardería por su id"
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Alumno obtenido con éxito"),
        @ApiResponse(responseCode = "404", description = "Alumno no encontrado")
    })
    @GetMapping("/{id}")
    public Child getChild(@PathVariable Integer id) {
        return childService.getChildById(id);
    }


    @Operation(
        summary = "Actualizar un alumno de la guardería",
        description = "Actualiza un alumno de la guardería por su id"
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Alumno actualizado con éxito"),
        @ApiResponse(responseCode = "404", description = "Alumno no encontrado")
    })
    @PutMapping("/{id}")
    public Child updateChild(@PathVariable Integer id, @RequestBody Child childDetails) {
        return childService.updateChild(id, childDetails);
    }


    @Operation(
        summary = "Eliminar un alumno de la guardería",
        description = "Elimina un alumno de la guardería por su id"
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Alumno eliminado con éxito"),
        @ApiResponse(responseCode = "404", description = "Alumno no encontrado")
    })  
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteChild(@PathVariable Integer id) {
        childService.deleteChild(id);
        return ResponseEntity.ok().build();
    }

}