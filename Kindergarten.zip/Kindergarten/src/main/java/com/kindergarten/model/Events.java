package com.kindergarten.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

//swagger
import io.swagger.v3.oas.annotations.media.Schema;

@Schema(name = "Events", description = "Eventos del infante en la guardería")
@Entity
public class Events {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Integer id;
    private String firstName;
    private String lastName;
    private String circunstancias;

    @Schema(description = "Correo electrónico del padre")
    private String email;

    public Events() {
    }

    // Constructor, getters y setters

    public Events(Integer id, String firstName, String lastName, String circunstancias,String email) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.circunstancias=circunstancias;
        this.email = email;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCircunstancias() {
        return circunstancias;
    }

    public void setCircunstancias(String circunstancias) {
        this.circunstancias = circunstancias;
    }


    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "Parent{" +
                "id='" + id + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", circunstancias='" + circunstancias + '\'' +
                '}';
    }
}