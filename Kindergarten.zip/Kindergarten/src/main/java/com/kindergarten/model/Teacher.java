package com.kindergarten.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

//swagger
import io.swagger.v3.oas.annotations.media.Schema;

@Schema(name = "Teacher", description = "Profesor de un alumno de la guardería")
@Entity
public class Teacher {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Integer id;
    private String firstName;
    private String lastName;
    private String especialidad;

    @Schema(description = "Correo electrónico del profesor")
    private String email;

    public Teacher() {
    }

    // Constructor, getters y setters

    public Teacher(Integer id, String firstName, String lastName, String especialidad,String email) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.especialidad= especialidad;
        this.email = email;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "Parent{" +
                "id='" + id + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", especialidad='" + especialidad + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}